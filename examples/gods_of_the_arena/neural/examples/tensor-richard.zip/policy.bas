dim tensorShape(0)
sub tensorRichardWeightsInitialize()
  trWeightsEncoder = tensorLoad(trWeightsPrefix$ + ".encoder")
  trWeightsEncoderBias = tensorLoad(trWeightsPrefix$ + ".encoderBias")
  trWeightsDecoder = tensorLoad(trWeightsPrefix$ + ".decoder")
  trWeightsDecoderBias = tensorLoad(trWeightsPrefix$ + ".decoderBias")
  trWeightsInputs = tensorDim(trWeightsEncoder, 1)
  trWeightsHidden = tensorDim(trWeightsEncoder, 0)
  trWeightsOutputs = tensorDim(trWeightsDecoder, 0)
  trWeightsKind = tensorDtype(trWeightsEncoder)
  trWeightsType$ = "int32"
  if trWeightsKind = 1 then
    trWeightsType$ = "fixed"
  end if
  tensorShape(0) = trWeightsInputs
  trWeightsInput = tensorCreate(trWeightsType$, tensorShape)
  tensorShape(0) = trWeightsHidden
  trWeightsActivation = tensorCreate(trWeightsType$, tensorShape)
  tensorShape(0) = trWeightsOutputs
  trWeightsLogits = tensorCreate(trWeightsType$, tensorShape)
  tensorShape(0) = trWeightsOutputs
  trWeightsFixedScores = tensorCreate("fixed", tensorShape)
  trWeightsHundred = tensorScalar("fixed", "100")
end sub

sub tensorRichardWeightsStep()
  tensorImport(trWeightsInput, trWeightsData)
  if trWeightsKind = 1 then
    tensorDivide(trWeightsInput, trWeightsHundred, trWeightsInput)
  end if
  tensorDense(trWeightsInput, trWeightsEncoder, trWeightsEncoderBias, trWeightsActivation)
  tensorRelu(trWeightsActivation, trWeightsActivation)
  tensorDense(trWeightsActivation, trWeightsDecoder, trWeightsDecoderBias, trWeightsLogits)
  if trWeightsKind = 0 then
    tensorReinterpret(trWeightsLogits, trWeightsFixedScores)
  else
    tensorCopy(trWeightsLogits, trWeightsFixedScores)
  end if
  trWeightsResult = tensorExport(trWeightsFixedScores)
end sub

' Synthetic test example written for this API, not a submitted player policy.
' Pair it with the generated weights.bin fixture; no trained weights are used.
dim data(24)
if drafting then
  for i = 0 to 9
    if heroAvailable(i) then
      draftHero(i)
      end
    end if
  next i
  end
end if
if initialized = 0 then
  state = blobCreate()
  initialized = 1
end if
if selfHp <= 0 then
  blobClear(state)
  end
end if
data(0) = selfHp * 100 \ selfMaxHp
if trWeightsReady = 0 then
  trWeightsPrefix$ = "weights"
  tensorRichardWeightsInitialize()
  trWeightsReady = 1
end if
trWeightsData = data
tensorRichardWeightsStep()
res = trWeightsResult
best = 0
for i = 1 to 17
  if res(i) > res(best) then
    best = i
  end if
next i
' Interpret the chosen score using ordinary game commands.
if best = 0 then
  walkTo(selfX, selfY)
end if
